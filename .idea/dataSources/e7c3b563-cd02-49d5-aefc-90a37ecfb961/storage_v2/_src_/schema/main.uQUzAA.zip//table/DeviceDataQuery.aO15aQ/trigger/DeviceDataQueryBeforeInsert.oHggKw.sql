CREATE TRIGGER DeviceDataQueryBeforeInsert
BEFORE INSERT ON DeviceDataQuery
BEGIN
    SELECT CASE
        WHEN (SELECT COUNT(*) FROM DeviceDataQuery WHERE element_id = NEW.element_id) > 0
        THEN RAISE(ABORT, 'Data for this element already exists')
    END;
END;

